#!/bin/zsh

g++ $1.cpp -o $1 -Wall -Wextra -Wconversion -fsanitize=undefined -std=c++11