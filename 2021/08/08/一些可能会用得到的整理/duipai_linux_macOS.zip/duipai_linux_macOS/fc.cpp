#include<bits/stdc++.h>

using namespace std;

int main(int argc,char* argv[]){
    if(argc>1&&strcmp(argv[1],"1")==0){
        system("./G.sh bf");
        system("./G.sh mk");
        system("./G.sh std");
    }
    int q=10;
    while(q--){
        system("./mk > input.txt");
        cerr<<"std time:\033[0;32m";
        system("time ./std < input.txt > ans.txt");
        cerr<<"\033[0m\n";
        cerr<<"bf time:\033[0;33m";
        system("time ./bf < input.txt > bfans.txt");
        cerr<<"\033[0m\n";
        cerr<<"py time:\033[0;34m";
        system("time python3 bf.py < input.txt > pybfans.txt");
        cerr<<"\033[0m\n";
        cerr<<"\033[0;31m";
        system("diff ans.txt bfans.txt");
        cerr<<"\033[0m\n";
        cerr<<"\033[0;31m";
        system("diff ans.txt pybfans.txt");
        cerr<<"\033[0m\n";
        system("sleep 2");
    }
    return 0;
}