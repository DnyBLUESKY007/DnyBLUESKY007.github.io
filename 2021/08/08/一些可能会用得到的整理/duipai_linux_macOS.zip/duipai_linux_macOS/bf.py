def init():

def main():
    init()

if __name__=='__main__':
    main()
